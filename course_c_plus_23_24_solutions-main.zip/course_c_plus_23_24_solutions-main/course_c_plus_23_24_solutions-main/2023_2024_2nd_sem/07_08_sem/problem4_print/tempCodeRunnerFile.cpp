void print(int a) {
    std::cout << "int " << a << '\n';
}
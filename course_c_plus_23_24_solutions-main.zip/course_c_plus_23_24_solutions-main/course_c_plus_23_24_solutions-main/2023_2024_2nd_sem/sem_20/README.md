# DSBA Introduction to Programming // Workshops 20
Spring semester 2023/24

Classes, headers, static fields, exceptions.

//
// Created by Mariia Gordenko on 16.01.2024.
//

#include "calculator.h"

int divide(int a, int b) {
  return a / b;
}
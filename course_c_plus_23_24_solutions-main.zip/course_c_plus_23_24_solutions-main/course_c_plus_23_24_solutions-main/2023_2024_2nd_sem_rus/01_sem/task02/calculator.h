//
// Created by Mariia Gordenko on 16.01.2024.
//

int plus(int a, int b);
int minus(int a, int b);
int multiply(int a, int b);
int divide(int a, int b);
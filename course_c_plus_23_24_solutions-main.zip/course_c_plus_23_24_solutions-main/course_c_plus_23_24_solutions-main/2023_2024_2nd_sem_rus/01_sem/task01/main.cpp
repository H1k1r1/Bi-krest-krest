#include <iostream>
#include "function.h"

int main() {
  print_smth();
  std::cout << "Hello, World!" << std::endl;
  return 0;
}
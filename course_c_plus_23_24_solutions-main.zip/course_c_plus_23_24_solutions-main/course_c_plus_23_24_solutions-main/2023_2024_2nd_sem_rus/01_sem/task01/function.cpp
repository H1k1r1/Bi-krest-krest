//
// Created by Mariia Gordenko on 16.01.2024.
//
#include <iostream>

void print_smth() {
  std::cout << "Print, smth!" << std::endl;
}
int main1() {
//   std::vector<Circle> circles;
//   std::vector<Rectangle> rectangles;

//   for (int i = 0; i < 5; ++i) {
//     circles.push_back(Circle(0, 0, rand() % 10 + 1));
//     rectangles.push_back(Rectangle(0, 0, rand() % 10 + 1, rand() % 10 + 1));
//   }

//   for (const auto &circle : circles) {
//     std::cout << "Circle Area: " << circle.area() << std::endl;
//   }

//   for (const auto &rectangle : rectangles) {
//     std::cout << "Rectangle Area: " << rectangle.area() << std::endl;
//   }

//   return 0;
// }
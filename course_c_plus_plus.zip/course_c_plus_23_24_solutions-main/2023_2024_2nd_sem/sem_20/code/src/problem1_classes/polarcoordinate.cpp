#include "polarcoordinate.h"

PolarCoordinate::PolarCoordinate()
{
}

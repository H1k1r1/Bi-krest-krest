# DSBA Introduction to Programming // Workshops 18
Spring semester 2023/24

Structures, classes, operators, fields, methods.

Workshop tasks are in the included PDF.

Useful resource about operators: https://en.cppreference.com/w/cpp/language/expressions
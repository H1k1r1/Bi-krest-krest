for (const auto &flight : flights) {
    std::cout << flight << std::endl;
  }